-- Teer Hub schema
CREATE TABLE IF NOT EXISTS centers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL UNIQUE,
  timezone VARCHAR(50) DEFAULT 'Asia/Kolkata',
  is_active TINYINT DEFAULT 1
);

INSERT IGNORE INTO centers (name) VALUES ('SHILLONG'), ('JUWAI'), ('KHANAPARA'), ('NIGHT'), ('SUNDAY');

CREATE TABLE IF NOT EXISTS sessions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  center_id INT NOT NULL,
  label VARCHAR(20) NOT NULL, -- First/Second/Night
  scheduled_time_local TIME NOT NULL,
  FOREIGN KEY (center_id) REFERENCES centers(id)
);

-- Defaults for Shillong (4 PM, 5 PM)
INSERT IGNORE INTO sessions (center_id, label, scheduled_time_local)
SELECT id, 'FIRST', '16:00:00' FROM centers WHERE name='SHILLONG';
INSERT IGNORE INTO sessions (center_id, label, scheduled_time_local)
SELECT id, 'SECOND', '17:00:00' FROM centers WHERE name='SHILLONG';

CREATE TABLE IF NOT EXISTS results (
  id INT AUTO_INCREMENT PRIMARY KEY,
  center_id INT NOT NULL,
  date DATE NOT NULL,
  round ENUM('FR','SR') NOT NULL,
  number CHAR(2) NOT NULL,
  published_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  source_note VARCHAR(255),
  UNIQUE KEY uniq (center_id, date, round),
  FOREIGN KEY (center_id) REFERENCES centers(id)
);

CREATE TABLE IF NOT EXISTS predictions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  date DATE NOT NULL,
  center_id INT NOT NULL,
  type ENUM('DIRECT','HOUSE','ENDING') NOT NULL,
  values_json JSON NOT NULL,
  method_version VARCHAR(20) DEFAULT '1.0',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS prediction_accuracy (
  id INT AUTO_INCREMENT PRIMARY KEY,
  date DATE NOT NULL,
  center_id INT NOT NULL,
  matched_fr TINYINT DEFAULT 0,
  matched_sr TINYINT DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS dream_numbers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  dream_symbol VARCHAR(255) NOT NULL,
  numbers VARCHAR(255) NOT NULL,
  house VARCHAR(50),
  endings VARCHAR(50),
  tags VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  twofa_secret VARCHAR(64),
  twofa_enabled TINYINT DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sources (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  url VARCHAR(255) NOT NULL,
  is_active TINYINT DEFAULT 1
);