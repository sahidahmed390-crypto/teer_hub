import express from 'express';
import { query } from '../config/db.js';
import dayjs from 'dayjs';

const router = express.Router();

router.get('/today', async (req, res) => {
  const today = dayjs().format('YYYY-MM-DD');
  const rows = await query(`
    SELECT c.name as center, r.round, r.number, r.published_at
    FROM results r JOIN centers c ON r.center_id = c.id
    WHERE r.date = ?`, [today]);
  res.json({ date: today, results: rows });
});

router.get('/results', async (req, res) => {
  const { from, to, center } = req.query;
  const params = [];
  let sql = `SELECT DATE_FORMAT(r.date, '%Y-%m-%d') as date, c.name as center, r.round, r.number
             FROM results r JOIN centers c ON r.center_id = c.id WHERE 1=1`;
  if (from) { sql += ' AND r.date >= ?'; params.push(from); }
  if (to) { sql += ' AND r.date <= ?'; params.push(to); }
  if (center) { sql += ' AND c.name = ?'; params.push(center); }
  sql += ' ORDER BY r.date DESC, c.name, r.round';
  const rows = await query(sql, params);
  res.json(rows);
});

router.get('/predictions/today', async (req, res) => {
  const rows = await query(`
    SELECT p.*, c.name as center
    FROM predictions p JOIN centers c ON p.center_id = c.id
    WHERE p.date = CURDATE()
  `);
  res.json(rows);
});

router.get('/dreams', async (req, res) => {
  const q = (req.query.q || '').trim();
  let sql = 'SELECT * FROM dream_numbers';
  const params = [];
  if (q) {
    sql += ' WHERE dream_symbol LIKE ? OR numbers LIKE ? OR tags LIKE ?';
    params.push('%'+q+'%', '%'+q+'%', '%'+q+'%');
  }
  sql += ' ORDER BY dream_symbol ASC LIMIT 500';
  const rows = await query(sql, params);
  res.json(rows);
});

export default router;