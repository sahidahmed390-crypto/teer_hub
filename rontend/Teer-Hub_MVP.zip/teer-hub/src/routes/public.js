import express from 'express';
import { getTodayResults, getArchivePreview, getDreamPreview, getPredictionsToday, listCenters } from '../services/ui-data.js';
import { ensureAdmin, ensureAuthed } from '../middleware/auth.js';
import { exportCSV, exportExcel, exportPDF } from '../services/exporter.js';
import { query } from '../config/db.js';

const router = express.Router();

export default function(csrfProtection) {
  router.get('/', async (req, res) => {
    const [today, preview, dreamPreview, preds, centers] = await Promise.all([
      getTodayResults(),
      getArchivePreview(),
      getDreamPreview(),
      getPredictionsToday(),
      listCenters()
    ]);
    res.render('index', { title: 'Teer Hub — Live Results', today, preview, dreamPreview, preds, centers });
  });

  router.get('/results', async (req, res) => {
    const centers = await listCenters();
    res.render('results', { title: 'Results', centers });
  });

  router.get('/predictions', async (req, res) => {
    res.render('predictions', { title: 'Predictions' });
  });

  router.get('/dreams', async (req, res) => {
    res.render('dreams', { title: 'Dream Chart' });
  });

  router.get('/archive', async (req, res) => {
    res.render('archive', { title: 'Archive' });
  });

  // Export endpoints (GET with query params)
  router.get('/export/csv', exportCSV);
  router.get('/export/excel', exportExcel);
  router.get('/export/pdf', exportPDF);

  router.get('/login', (req, res) => res.render('admin/login', { title: 'Admin Login', csrfToken: req.csrfToken() }));

  return router;
}