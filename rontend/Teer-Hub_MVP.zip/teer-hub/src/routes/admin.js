import express from 'express';
import { ensureAuthed } from '../middleware/auth.js';
import { query } from '../config/db.js';
import bcrypt from 'bcryptjs';
import speakeasy from 'speakeasy';
import QRCode from 'qrcode';

const router = express.Router();

export default function(csrfProtection) {
  // Login
  router.get('/login', (req, res) => res.render('admin/login', { title: 'Admin Login', csrfToken: req.csrfToken() }));
  router.post('/login', csrfProtection, async (req, res) => {
    const { email, password, token } = req.body;
    const rows = await query('SELECT * FROM admins WHERE email=?', [email]);
    if (!rows.length) return res.render('admin/login', { title: 'Admin Login', error: 'Invalid credentials', csrfToken: req.csrfToken() });
    const admin = rows[0];
    if (!bcrypt.compareSync(password, admin.password_hash)) {
      return res.render('admin/login', { title: 'Admin Login', error: 'Invalid credentials', csrfToken: req.csrfToken() });
    }
    if (admin.twofa_enabled) {
      const verified = speakeasy.totp.verify({ secret: admin.twofa_secret, encoding: 'base32', token });
      if (!verified) return res.render('admin/login', { title: 'Admin Login', error: 'Invalid 2FA token', csrfToken: req.csrfToken() });
    }
    req.session.adminId = admin.id;
    res.redirect('/admin');
  });

  router.get('/logout', (req, res) => { req.session.destroy(()=>{}); res.redirect('/'); });

  // Dashboard
  router.get('/', ensureAuthed, async (req, res) => {
    const counts = await query(`
      SELECT (SELECT COUNT(*) FROM results) as results_count,
             (SELECT COUNT(*) FROM dream_numbers) as dreams_count,
             (SELECT COUNT(*) FROM predictions WHERE date=CURDATE()) as preds_today
    `);
    res.render('admin/dashboard', { title: 'Admin', counts: counts[0] });
  });

  // Sources management
  router.get('/sources', ensureAuthed, async (req, res) => {
    const sources = await query('SELECT * FROM sources ORDER BY is_active DESC, id ASC');
    res.render('admin/sources', { title: 'Sources', sources, csrfToken: req.csrfToken() });
  });
  router.post('/sources', ensureAuthed, csrfProtection, async (req, res) => {
    const { name, url } = req.body;
    await query('INSERT INTO sources (name, url, is_active) VALUES (?, ?, 1)', [name, url]);
    res.redirect('/admin/sources');
  });
  router.post('/sources/:id/toggle', ensureAuthed, csrfProtection, async (req, res) => {
    const { id } = req.params;
    await query('UPDATE sources SET is_active = 1 - is_active WHERE id=?', [id]);
    res.redirect('/admin/sources');
  });

  // Results manual override
  router.get('/results', ensureAuthed, async (req, res) => {
    const centers = await query('SELECT * FROM centers WHERE is_active=1');
    res.render('admin/results', { title: 'Results Override', centers, csrfToken: req.csrfToken() });
  });
  router.post('/results', ensureAuthed, csrfProtection, async (req, res) => {
    const { center_id, date, round, number } = req.body;
    await query(`INSERT INTO results (center_id, date, round, number) VALUES (?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE number=VALUES(number), published_at=NOW(), source_note='manual'`,
                 [center_id, date, round, number]);
    res.redirect('/admin/results');
  });

  // Dream Chart CRUD (list + add quick form)
  router.get('/dreams', ensureAuthed, async (req, res) => {
    const rows = await query('SELECT * FROM dream_numbers ORDER BY dream_symbol ASC LIMIT 1000');
    res.render('admin/dreams', { title: 'Dream Chart', rows, csrfToken: req.csrfToken() });
  });
  router.post('/dreams', ensureAuthed, csrfProtection, async (req, res) => {
    const { dream_symbol, numbers, house, endings, tags } = req.body;
    await query('INSERT INTO dream_numbers (dream_symbol, numbers, house, endings, tags) VALUES (?,?,?,?,?)',
      [dream_symbol, numbers, house, endings, tags]);
    res.redirect('/admin/dreams');
  });

  // Admin profile for 2FA
  router.get('/profile', ensureAuthed, async (req, res) => {
    const rows = await query('SELECT * FROM admins WHERE id=?', [req.session.adminId]);
    const admin = rows[0];
    if (!admin.twofa_enabled) {
      const secret = speakeasy.generateSecret({ name: 'TeerHub Admin' });
      const qr = await QRCode.toDataURL(secret.otpauth_url);
      req.session.pending2FA = secret.base32;
      return res.render('admin/profile', { title: 'Profile', admin, qr, secret: secret.base32, csrfToken: req.csrfToken() });
    }
    res.render('admin/profile', { title: 'Profile', admin, qr: null, secret: null, csrfToken: req.csrfToken() });
  });
  router.post('/profile/2fa/enable', ensureAuthed, csrfProtection, async (req, res) => {
    const token = req.body.token;
    const secret = req.session.pending2FA;
    const verified = speakeasy.totp.verify({ secret, encoding: 'base32', token });
    if (verified) {
      await query('UPDATE admins SET twofa_secret=?, twofa_enabled=1 WHERE id=?', [secret, req.session.adminId]);
      delete req.session.pending2FA;
      return res.redirect('/admin/profile');
    }
    res.redirect('/admin/profile');
  });

  return router;
}