document.addEventListener('DOMContentLoaded', () => {
  const year = document.getElementById('year'); if (year) year.textContent = new Date().getFullYear();
  const menuBtn = document.getElementById('menuBtn');
  const mobileNav = document.getElementById('mobileNav');
  if (menuBtn && mobileNav) menuBtn.addEventListener('click', ()=> mobileNav.classList.toggle('hidden'));

  // Dark mode toggle
  const toggle = document.getElementById('darkToggle');
  const root = document.documentElement;
  if (localStorage.theme === 'dark') root.classList.add('dark');
  toggle?.addEventListener('click', () => {
    root.classList.toggle('dark');
    localStorage.theme = root.classList.contains('dark') ? 'dark' : 'light';
  });

  // Countdown to next 4PM or 5PM
  const cd = document.getElementById('countdown');
  function nextDrawDate() {
    const now = new Date();
    const next = new Date(now);
    next.setSeconds(0); next.setMilliseconds(0);
    const h = now.getHours();
    if (h < 16) { next.setHours(16, 0, 0, 0); }
    else if (h < 17) { next.setHours(17, 0, 0, 0); }
    else { next.setDate(next.getDate()+1); next.setHours(16,0,0,0); }
    return next;
  }
  function renderCountdown() {
    if (!cd) return;
    const target = nextDrawDate();
    const diff = target - new Date();
    const totalSec = Math.max(0, Math.floor(diff/1000));
    const hh = String(Math.floor(totalSec/3600)).padStart(2,'0');
    const mm = String(Math.floor((totalSec%3600)/60)).padStart(2,'0');
    const ss = String(totalSec%60).padStart(2,'0');
    cd.innerHTML = '';
    [hh,mm,ss].join(':').split('').forEach(ch => {
      const d = document.createElement('div');
      d.className = 'digit';
      const s = document.createElement('span');
      s.textContent = ch;
      d.appendChild(s); cd.appendChild(d);
      setTimeout(()=> d.classList.add('flip'), 10);
    });
  }
  setInterval(renderCountdown, 1000); renderCountdown();

  // Live results polling
  async function refreshLive() {
    try {
      const res = await fetch('/api/today'); const data = await res.json();
      const frEl = document.getElementById('fr'); const srEl = document.getElementById('sr');
      const fr = data.results.find(r => r.round === 'FR');
      const sr = data.results.find(r => r.round === 'SR');
      if (fr && frEl && frEl.textContent !== fr.number) { frEl.textContent = fr.number; frEl.classList.add('pulse'); setTimeout(()=>frEl.classList.remove('pulse'), 1200); }
      if (sr && srEl && srEl.textContent !== sr.number) { srEl.textContent = sr.number; srEl.classList.add('pulse'); setTimeout(()=>srEl.classList.remove('pulse'), 1200); }
    } catch(e){}
  }
  setInterval(refreshLive, 30000); refreshLive();

  // Predictions cards
  async function loadPreds() {
    const res = await fetch('/api/predictions/today'); const rows = await res.json();
    const container = document.getElementById('predCards');
    if (!container) return;
    container.innerHTML = '';
    const centers = {};
    rows.forEach(r => {
      const c = r.center; centers[c] = centers[c] || { DIRECT: [], HOUSE: [], ENDING: [] };
      centers[c][r.type] = JSON.parse(r.values_json);
    });
    for (const [center, sets] of Object.entries(centers)) {
      const card = document.createElement('div');
      card.className = 'min-w-[260px] rounded-xl bg-gray-100 dark:bg-gray-900 p-4';
      card.innerHTML = `<div class="text-xs text-gray-500">${center}</div>
      <div class="mt-1"><span class="font-bold">Direct:</span> ${sets.DIRECT.join(', ') || '-'}</div>
      <div><span class="font-bold">House:</span> ${sets.HOUSE.join(', ') || '-'}</div>
      <div><span class="font-bold">Ending:</span> ${sets.ENDING.join(', ') || '-'}</div>`;
      container.appendChild(card);
    }
  }
  loadPreds();

  // Dream preview
  async function loadDreamPreview(q='') {
    const res = await fetch('/api/dreams?q=' + encodeURIComponent(q));
    const rows = await res.json();
    const box = document.getElementById('dreamPreview');
    const full = document.getElementById('dreamTable');
    const target = box || full;
    if (!target) return;
    target.innerHTML = '';
    const head = `<div class="grid grid-cols-4 font-bold"><div>Dream</div><div>Numbers</div><div>House</div><div>Endings</div></div>`;
    target.insertAdjacentHTML('beforeend', head);
    rows.slice(0, box ? 3 : 500).forEach(r => {
      const row = `<div class="grid grid-cols-4 border-t border-gray-200 dark:border-gray-700 py-1">
        <div>${r.dream_symbol}</div><div>${r.numbers}</div><div>${r.house||'-'}</div><div>${r.endings||'-'}</div>
      </div>`;
      target.insertAdjacentHTML('beforeend', row);
    });
  }
  loadDreamPreview();
  document.getElementById('dreamSearch')?.addEventListener('input', (e)=> loadDreamPreview(e.target.value));
  document.getElementById('dreamSearchFull')?.addEventListener('input', (e)=> loadDreamPreview(e.target.value));

  // Archive preview
  async function loadArchivePreview() {
    const res = await fetch('/api/results?from=&to=');
    const rows = await res.json();
    const byDate = {};
    rows.forEach(r => {
      byDate[r.date] = byDate[r.date] || { FR: '--', SR: '--' };
      byDate[r.date][r.round] = r.number;
    });
    const ap = document.getElementById('archivePreview'); if (!ap) return;
    ap.innerHTML = '';
    Object.entries(byDate).slice(0,5).forEach(([date, rs]) => {
      ap.insertAdjacentHTML('beforeend', `<div class="flex justify-between border-t border-gray-200 dark:border-gray-700 py-1"><div>${date}</div><div>FR: ${rs.FR} | SR: ${rs.SR}</div></div>`);
    });
  }
  loadArchivePreview();

  // Results page table + exports
  async function runFilter() {
    const from = document.getElementById('from')?.value || '';
    const to = document.getElementById('to')?.value || '';
    const center = document.getElementById('center')?.value || '';
    const url = `/api/results?from=${from}&to=${to}&center=${encodeURIComponent(center)}`;
    const res = await fetch(url); const rows = await res.json();
    const table = document.getElementById('resultsTable');
    if (!table) return;
    table.innerHTML = '<table class="min-w-full"><tr><th class="text-left p-2">Date</th><th class="text-left p-2">Center</th><th class="text-left p-2">Round</th><th class="text-left p-2">Number</th></tr></table>';
    const tbody = document.createElement('tbody'); table.querySelector('table').appendChild(tbody);
    rows.forEach(r => {
      const tr = document.createElement('tr');
      tr.className = 'border-t border-gray-200 dark:border-gray-700';
      tr.innerHTML = `<td class="p-2">${r.date}</td><td class="p-2">${r.center}</td><td class="p-2">${r.round}</td><td class="p-2 font-bold">${r.number}</td>`;
      tbody.appendChild(tr);
    });

    // Export links
    document.getElementById('csv')?.setAttribute('href', `/export/csv?from=${from}&to=${to}&center=${encodeURIComponent(center)}`);
    document.getElementById('xlsx')?.setAttribute('href', `/export/excel?from=${from}&to=${to}&center=${encodeURIComponent(center)}`);
    document.getElementById('pdf')?.setAttribute('href', `/export/pdf?from=${from}&to=${to}&center=${encodeURIComponent(center)}`);
  }
  document.getElementById('runFilter')?.addEventListener('click', runFilter);
  if (document.getElementById('resultsTable')) runFilter();

  // Predictions accuracy chart placeholder (fetch from API if implemented)
  async function loadAccuracy() {
    // In a real deployment, add an API to fetch last 30 days accuracy.
    const ctx = document.getElementById('accChart');
    if (!ctx) return;
    const labels = Array.from({length:30}).map((_,i)=>`D-${30-i}`);
    const data = Array.from({length:30}).map(()=>Math.floor(Math.random()*2)); // placeholder 0/1
    // eslint-disable-next-line no-undef
    new Chart(ctx, { type: 'bar', data: { labels, datasets: [{ label: 'Matched (FR or SR)', data }] } });
  }
  loadAccuracy();
});