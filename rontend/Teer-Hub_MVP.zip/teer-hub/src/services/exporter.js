import { query } from '../config/db.js';
import XLSX from 'xlsx';
import PDFDocument from 'pdfkit';
import { Readable } from 'stream';

export async function exportCSV(req, res) {
  const rows = await fetchRows(req);
  const header = Object.keys(rows[0] || { date: '', center: '', round: '', number: '' }).join(',') + '\n';
  const csv = header + rows.map(r => `${r.date},${r.center},${r.round},${r.number}`).join('\n');
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="teer-results.csv"');
  res.send(csv);
}

export async function exportExcel(req, res) {
  const rows = await fetchRows(req);
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Results');
  const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', 'attachment; filename="teer-results.xlsx"');
  res.send(buf);
}

export async function exportPDF(req, res) {
  const rows = await fetchRows(req);
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', 'attachment; filename="teer-results.pdf"');
  const doc = new PDFDocument({ margin: 40, size: 'A4' });
  doc.fontSize(18).text('Teer Results Export', { align: 'center' });
  doc.moveDown();
  doc.fontSize(10);
  rows.forEach(r => {
    doc.text(`${r.date}  |  ${r.center}  |  ${r.round}  |  ${r.number}`);
  });
  doc.end();
  doc.pipe(res);
}

async function fetchRows(req) {
  const { from, to, center } = req.query;
  const params = [];
  let sql = `SELECT DATE_FORMAT(r.date, '%Y-%m-%d') as date, c.name as center, r.round, r.number
             FROM results r JOIN centers c ON r.center_id = c.id WHERE 1=1`;
  if (from) { sql += ' AND r.date >= ?'; params.push(from); }
  if (to) { sql += ' AND r.date <= ?'; params.push(to); }
  if (center) { sql += ' AND c.name = ?'; params.push(center); }
  sql += ' ORDER BY r.date DESC, c.name, r.round';
  const rows = await query(sql, params);
  return rows;
}