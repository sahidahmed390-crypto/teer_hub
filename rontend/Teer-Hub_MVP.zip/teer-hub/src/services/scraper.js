import axios from 'axios';
import cheerio from 'cheerio';
import { query } from '../config/db.js';

function extractNumbersFromHtml(html) {
  const $ = cheerio.load(html);
  const text = $('body').text().replace(/\s+/g, ' ');
  const matches = text.match(/\b\d{2}\b/g) || [];
  // Heuristic: pick likely FR/SR pairs (first two unique two-digits)
  const uniq = [...new Set(matches)];
  return uniq.slice(0, 2);
}

export async function fetchResultsFromSource(url) {
  try {
    const res = await axios.get(url, { timeout: 15000, headers: { 'User-Agent': 'TeerHubBot/1.0' } });
    const nums = extractNumbersFromHtml(res.data);
    return nums;
  } catch (e) {
    return [];
  }
}

export async function saveResult(centerName, dateStr, round, number, source_note) {
  const centers = await query('SELECT id FROM centers WHERE name=?', [centerName]);
  if (!centers.length) return;
  const center_id = centers[0].id;
  await query(`INSERT INTO results (center_id, date, round, number, source_note)
               VALUES (?, ?, ?, ?, ?)
               ON DUPLICATE KEY UPDATE number=VALUES(number), published_at=NOW(), source_note=VALUES(source_note)`,
               [center_id, dateStr, round, number, source_note]);
}

export async function runScrapeCycle() {
  const primary = process.env.RESULT_SOURCE_PRIMARY;
  const fallbacks = (process.env.RESULT_SOURCE_FALLBACKS || '').split(',').map(s=>s.trim()).filter(Boolean);
  const sources = [primary, ...fallbacks].filter(Boolean);

  for (const src of sources) {
    const nums = await fetchResultsFromSource(src);
    if (nums.length >= 1) {
      const today = new Date().toISOString().slice(0,10);
      if (nums[0]) await saveResult('SHILLONG', today, 'FR', nums[0], new URL(src).hostname);
      if (nums[1]) await saveResult('SHILLONG', today, 'SR', nums[1], new URL(src).hostname);
      return true;
    }
  }
  return false;
}