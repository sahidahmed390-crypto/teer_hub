import { query } from '../config/db.js';
import dayjs from 'dayjs';

export async function listCenters() {
  return await query('SELECT * FROM centers WHERE is_active=1 ORDER BY name');
}

export async function getTodayResults() {
  const rows = await query(`
    SELECT c.name as center, r.round, r.number, r.published_at
    FROM results r JOIN centers c ON r.center_id = c.id
    WHERE r.date = CURDATE()
    ORDER BY c.name, r.round
  `);
  return rows;
}

export async function getArchivePreview() {
  const rows = await query(`
    SELECT DATE_FORMAT(date, '%Y-%m-%d') as date,
           MAX(CASE WHEN round='FR' THEN number END) as fr,
           MAX(CASE WHEN round='SR' THEN number END) as sr
    FROM results WHERE date >= DATE_SUB(CURDATE(), INTERVAL 5 DAY)
    GROUP BY date ORDER BY date DESC
  `);
  return rows;
}

export async function getDreamPreview() {
  const rows = await query(`SELECT dream_symbol, numbers, house, endings FROM dream_numbers ORDER BY dream_symbol ASC LIMIT 3`);
  return rows;
}

export async function getPredictionsToday() {
  const rows = await query(`
    SELECT c.name as center, p.type, p.values_json
    FROM predictions p JOIN centers c ON p.center_id=c.id
    WHERE p.date = CURDATE()
  `);
  // reshape
  const map = {};
  for (const r of rows) {
    map[r.center] = map[r.center] || { center: r.center, DIRECT: [], HOUSE: [], ENDING: [] };
    map[r.center][r.type] = JSON.parse(r.values_json);
  }
  return Object.values(map);
}