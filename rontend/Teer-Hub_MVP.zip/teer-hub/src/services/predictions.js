import { query } from '../config/db.js';

function topNCounts(arr, n) {
  const counts = {};
  for (const a of arr) counts[a] = (counts[a]||0) + 1;
  return Object.entries(counts).sort((a,b)=>b[1]-a[1]).slice(0,n).map(x=>x[0]);
}

export async function computeAndStorePredictions(centerName) {
  const rows = await query(`
    SELECT r.number FROM results r
    JOIN centers c ON r.center_id=c.id
    WHERE c.name=? AND r.date >= DATE_SUB(CURDATE(), INTERVAL 90 DAY)
  `, [centerName]);

  const nums = rows.map(r=>r.number).filter(Boolean);
  if (!nums.length) return;

  const endings = nums.map(n => n[1]);
  const houses = nums.map(n => n[0]);
  const topDirect = topNCounts(nums, 10);
  const topEndings = topNCounts(endings, 4);
  const topHouses = topNCounts(houses, 4);

  const center = await query('SELECT id FROM centers WHERE name=?', [centerName]);
  if (!center.length) return;
  const center_id = center[0].id;

  const pairs = [
    ['DIRECT', topDirect],
    ['HOUSE', topHouses],
    ['ENDING', topEndings]
  ];

  for (const [type, values] of pairs) {
    await query(`INSERT INTO predictions (date, center_id, type, values_json, method_version)
                 VALUES (CURDATE(), ?, ?, ?, '1.0')
                 ON DUPLICATE KEY UPDATE values_json=VALUES(values_json)`, [center_id, type, JSON.stringify(values)]);
  }

  // Accuracy tracking: did FR/SR fall in DIRECT set today?
  const today = await query(`
    SELECT r.round, r.number FROM results r
    WHERE r.center_id=? AND r.date = CURDATE()
  `, [center_id]);
  if (today.length) {
    const set = new Set(topDirect);
    const matched_fr = today.some(r => r.round === 'FR' && set.has(r.number)) ? 1 : 0;
    const matched_sr = today.some(r => r.round === 'SR' && set.has(r.number)) ? 1 : 0;
    await query(`INSERT INTO prediction_accuracy (date, center_id, matched_fr, matched_sr)
                 VALUES (CURDATE(), ?, ?, ?)
                 ON DUPLICATE KEY UPDATE matched_fr=VALUES(matched_fr), matched_sr=VALUES(matched_sr)`,
                 [center_id, matched_fr, matched_sr]);
  }
}