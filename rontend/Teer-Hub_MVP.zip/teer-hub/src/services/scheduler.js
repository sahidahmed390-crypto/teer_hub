import cron from 'node-cron';
import dayjs from 'dayjs';
import { runScrapeCycle } from './scraper.js';
import { computeAndStorePredictions } from './predictions.js';

export function scheduleJobs() {
  const tz = process.env.CRON_TZ || 'Asia/Kolkata';
  // Scrape not exactly at 4/5 to allow sources to publish; run at 16:05 and 17:05
  cron.schedule('5 16 * * *', async () => {
    await runScrapeCycle();
    await computeAndStorePredictions('SHILLONG');
  }, { timezone: tz });

  cron.schedule('5 17 * * *', async () => {
    await runScrapeCycle();
    await computeAndStorePredictions('SHILLONG');
  }, { timezone: tz });

  // Night example (optional): 22:05 and 23:05
  cron.schedule('5 22 * * *', async () => {
    await runScrapeCycle();
    await computeAndStorePredictions('SHILLONG');
  }, { timezone: tz });

  // Daily recompute at 00:10
  cron.schedule('10 0 * * *', async () => {
    await computeAndStorePredictions('SHILLONG');
  }, { timezone: tz });
}