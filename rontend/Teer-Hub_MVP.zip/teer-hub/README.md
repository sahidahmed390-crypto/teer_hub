# Teer Hub
Mobile-first, SEO-optimized Teer results platform with live fetching, countdown timers, archives, predictions, and a searchable Dream Chart.

## Quick Start
1. **Install** Node.js 18+ and MySQL 8+.
2. Clone / unzip this folder.
3. Copy `.env.example` to `.env` and set your MySQL credentials.
4. Install deps:
   ```bash
   npm install
   ```
5. Initialize DB & seed:
   ```bash
   npm run init:db
   npm run seed:dreams
   ```
6. Run the app:
   ```bash
   npm run dev
   ```
   Visit http://localhost:3000

### Admin Login
- Email: from `.env` `ADMIN_EMAIL`
- Password: from `.env` `ADMIN_PASSWORD`
- You can enable 2FA in Admin > Profile.

### Features
- Home: Countdown (4 PM / 5 PM IST), live results auto-update, predictions carousel, dream chart preview, archive preview.
- Results: Filter by date/center, export CSV/Excel/PDF.
- Predictions: Top frequents, houses, endings from last 90 days; accuracy tracking and 30-day chart.
- Dream Chart: Full-text search, editable via Admin.
- Archive: Paginated, searchable, exportable.
- Admin Panel: Manage sources, manual overrides, dream chart CRUD, view prediction accuracy, 2FA.

### Cron Jobs
Runs at 16:05 and 17:05 Asia/Kolkata (configurable) to fetch results from sources in `.env`.
Uses Cheerio scraper + regex fallback; stores provenance and avoids duplicates.

### Tech Stack
- Node.js + Express + EJS
- TailwindCSS (CDN) + Vanilla JS
- MySQL (mysql2)
- node-cron + axios + cheerio
- CSRF, helmet, rate limiting, input sanitization

### Notes
- Dream Chart is seeded with a **small starter dataset**. Expand via Admin > Dream Chart or import CSV at `admin/dreams/import`.
- PDF export is basic (tabular). CSV/Excel export is recommended for heavy use.
- All UI is mobile-first and responsive; countdown uses flip animation; results cards pulse on update.