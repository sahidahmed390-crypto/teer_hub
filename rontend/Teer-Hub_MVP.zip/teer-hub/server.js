import 'dotenv/config';
import express from 'express';
import path from 'path';
import helmet from 'helmet';
import compression from 'compression';
import session from 'express-session';
import MySQLStoreFactory from 'express-mysql-session';
import csrf from 'csurf';
import rateLimit from 'express-rate-limit';
import cookieParser from 'cookie-parser';
import morgan from 'morgan';
import favicon from 'serve-favicon';
import { fileURLToPath } from 'url';

import { pool } from './src/config/db.js';
import publicRoutes from './src/routes/public.js';
import apiRoutes from './src/routes/api.js';
import adminRoutes from './src/routes/admin.js';
import { scheduleJobs } from './src/services/scheduler.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'src', 'views'));

app.use(helmet({
  contentSecurityPolicy: false
}));
app.use(compression());
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser());
app.use(morgan('dev'));
app.use(express.static(path.join(__dirname, 'src', 'public'), { maxAge: '1h' }));

try { app.use(favicon(path.join(__dirname, 'src', 'public', 'img', 'favicon.ico'))); } catch(e) {}

const MySQLStore = MySQLStoreFactory(session);
const sessionStore = new MySQLStore({}, pool.promise());

app.use(session({
  secret: process.env.SESSION_SECRET || 'changeme',
  resave: false,
  saveUninitialized: false,
  store: sessionStore,
  cookie: { secure: false, httpOnly: true, sameSite: 'lax', maxAge: 1000*60*60*8 }
}));

const csrfProtection = csrf();
const apiLimiter = rateLimit({ windowMs: 60 * 1000, max: 120 }); // 120 req/min/IP

// Routes
app.use('/api', apiLimiter, apiRoutes);
app.use('/admin', adminRoutes(csrfProtection));
app.use('/', publicRoutes(csrfProtection));

// Error handlers
app.use((req, res) => res.status(404).render('404', { title: 'Not Found' }));
app.use((err, req, res, next) => {
  console.error(err);
  if (req.path.startsWith('/api')) {
    return res.status(500).json({ error: 'Server error' });
  }
  res.status(500).render('500', { title: 'Server Error', error: err.message });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Teer Hub running on http://localhost:${PORT}`);
  scheduleJobs(); // Start cron jobs after server starts
});