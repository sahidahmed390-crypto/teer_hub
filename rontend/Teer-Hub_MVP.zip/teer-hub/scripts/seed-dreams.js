import 'dotenv/config';
import { pool } from '../src/config/db.js';

const seed = [
  { dream_symbol: 'Accident', numbers: '05,18,72', house: '0,1,7', endings: '2,5,8', tags: 'danger,vehicle' },
  { dream_symbol: 'Baby', numbers: '06,24,60', house: '0,2,6', endings: '0,4,6', tags: 'family' },
  { dream_symbol: 'Snake', numbers: '14,35,89', house: '1,3,8', endings: '4,5,9', tags: 'fear,animal' },
  { dream_symbol: 'Wedding', numbers: '07,27,70', house: '0,2,7', endings: '0,2,7', tags: 'event' },
  { dream_symbol: 'Money', numbers: '08,28,80', house: '0,2,8', endings: '0,2,8', tags: 'wealth' }
];

async function main() {
  for (const row of seed) {
    await pool.promise().query(
      'INSERT INTO dream_numbers (dream_symbol, numbers, house, endings, tags) VALUES (?, ?, ?, ?, ?)',
      [row.dream_symbol, row.numbers, row.house, row.endings, row.tags]
    );
  }
  console.log('Dream chart seeded with starter entries. Add more via Admin.');
  process.exit(0);
}

main().catch(err => { console.error(err); process.exit(1); });