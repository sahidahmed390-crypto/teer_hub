import 'dotenv/config';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { pool } from '../src/config/db.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function main() {
  const sql = fs.readFileSync(path.join(__dirname, '..', 'src', 'models', 'schema.sql'), 'utf-8');
  await pool.promise().query(sql);
  // Bootstrap admin
  const email = process.env.ADMIN_EMAIL || 'admin@teerhub.local';
  const password = process.env.ADMIN_PASSWORD || 'changeMe123';
  const bcrypt = (await import('bcryptjs')).default;
  const hash = bcrypt.hashSync(password, 10);
  await pool.promise().query(
    'INSERT IGNORE INTO admins (email, password_hash) VALUES (?, ?)',
    [email, hash]
  );
  // Seed sources from .env
  const primary = process.env.RESULT_SOURCE_PRIMARY || '';
  const fallbacks = (process.env.RESULT_SOURCE_FALLBACKS || '').split(',').map(s => s.trim()).filter(Boolean);
  const all = [primary, ...fallbacks].filter(Boolean);
  for (const url of all) {
    await pool.promise().query('INSERT IGNORE INTO sources (name, url, is_active) VALUES (?, ?, 1)', [new URL(url).hostname, url]);
  }
  console.log('DB initialized and admin bootstrapped.');
  process.exit(0);
}

main().catch(err => { console.error(err); process.exit(1); });